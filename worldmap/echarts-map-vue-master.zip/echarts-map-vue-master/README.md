# echarts-map-vue

代码的相应解释参考：[https://zhuanlan.zhihu.com/p/513629308](https://zhuanlan.zhihu.com/p/513629308)

## Project setup

```
npm install
```

### Compiles and hot-reloads for development

```
npm run serve
```

### Compiles and minifies for production

```
npm run build
```
